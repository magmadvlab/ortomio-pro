/**
 * Calendar Page - Next.js Route
 * Vista principale calendario con integrazione task, meteo, luna
 */

'use client'

import React from 'react';
import CalendarAlmanac from '@/components/CalendarAlmanac';

export default function CalendarPage() {
  return (
    <div className="min-h-screen">
      <CalendarAlmanac />
    </div>
  );
}
