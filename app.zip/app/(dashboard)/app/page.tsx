'use client'

import React from 'react'
import { useTier } from '@/packages/core/hooks/useTier'
import { AppTier } from '@/packages/core/config/tiers'
import { ConsumerDashboard } from '@/components/consumer/Dashboard'
import { ProfessionalDashboard } from '@/components/professional/Dashboard'
import { FreeDashboard } from '@/components/shared/FreeDashboard'

export default function DashboardPage() {
  const { tier, isProfessional, isConsumer } = useTier()
  
  if (isProfessional) {
    return <ProfessionalDashboard />
  }
  
  if (isConsumer) {
    return <ConsumerDashboard />
  }
  
  return <FreeDashboard />
}

