'use client'

import React from 'react'
import { Sun, HelpCircle, BookOpen, Camera, Compass, BarChart3, Calendar } from 'lucide-react'
import Link from 'next/link'

export default function HelpPage() {
  return (
    <div className="min-h-screen p-4 sm:p-6 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
          <HelpCircle className="text-green-600" size={32} />
          Guida e Aiuto
        </h1>
        <p className="text-gray-600">
          Trova risposte alle domande più comuni e impara a usare tutte le funzionalità di OrtoMio
        </p>
      </div>

      <div className="space-y-8">
        {/* Sezione Esposizione Solare */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <Sun className="text-yellow-500" size={24} />
            <h2 className="text-2xl font-bold text-gray-900">Esposizione Solare</h2>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Cos'è l'esposizione solare?</h3>
              <p className="text-gray-700 mb-3">
                L'esposizione solare indica quante ore di sole diretto riceve il tuo orto ogni giorno. 
                Questo valore è fondamentale per decidere quali piante coltivare e quando piantarle.
              </p>
              <p className="text-gray-700">
                OrtoMio calcola l'esposizione solare considerando:
              </p>
              <ul className="list-disc list-inside text-gray-700 mt-2 space-y-1 ml-4">
                <li>La posizione geografica (latitudine e longitudine)</li>
                <li>La data e la stagione (il sole cambia altezza durante l'anno)</li>
                <li>Gli ostacoli circostanti (palazzi, alberi, montagne)</li>
                <li>L'orientamento del terreno</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Come viene calcolata?</h3>
              <p className="text-gray-700 mb-3">
                Il sistema calcola la posizione del sole ogni 10 minuti durante il giorno (dalle 6:00 alle 18:00) 
                e verifica se è bloccato da ostacoli. Le ore di sole diretto vengono poi sommate per ottenere 
                il totale giornaliero.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-3">
                <p className="text-sm text-blue-800">
                  <strong>Formula:</strong> Per ogni ostacolo, viene calcolato l'angolo di elevazione 
                  (arctan(altezza/distanza)). Se il sole ha un'elevazione più bassa dell'ostacolo nella stessa 
                  direzione, viene considerato bloccato.
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Come aggiungere ostacoli?</h3>
              <p className="text-gray-700 mb-3">
                Puoi aggiungere ostacoli in due modi:
              </p>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Camera className="text-green-600 flex-shrink-0 mt-1" size={20} />
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">Foto 360° (Consigliato)</h4>
                    <p className="text-sm text-gray-700">
                      Scatta una foto panoramica 360° dal punto centrale del tuo orto. Il sistema analizzerà 
                      automaticamente la foto e identificherà gli ostacoli (edifici, alberi, montagne) con 
                      direzione, altezza e distanza stimata.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Compass className="text-blue-600 flex-shrink-0 mt-1" size={20} />
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">Input Manuale</h4>
                    <p className="text-sm text-gray-700">
                      Inserisci manualmente direzione (Nord, Sud, Est, Ovest), altezza in metri, distanza in metri 
                      e larghezza angolare. Utile se conosci già le misure precise.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Come interpretare i risultati?</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-medium">
                    Pieno Sole (8+ ore)
                  </span>
                  <span className="text-sm text-gray-700">
                    Ideale per pomodori, peperoni, zucchine, melanzane
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                    Sole Parziale (5-7 ore)
                  </span>
                  <span className="text-sm text-gray-700">
                    Buono per molte verdure: fagiolini, piselli, carote, cipolle
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                    Mezz'Ombra (3-4 ore)
                  </span>
                  <span className="text-sm text-gray-700">
                    Ideale per lattughe, spinaci, rucola, bietole, cavoli
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium">
                    Ombra (&lt;3 ore)
                  </span>
                  <span className="text-sm text-gray-700">
                    Solo piante da ombra o considera di spostare l'orto
                  </span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Grafico Mensile</h3>
              <p className="text-gray-700 mb-3">
                Il grafico mostra le ore medie di sole per ogni mese dell'anno. Il periodo ottimale 
                (evidenziato in verde) indica i mesi con almeno 6 ore di sole, ideali per la maggior parte 
                delle colture.
              </p>
              <p className="text-gray-700">
                Usa questo grafico per pianificare quando piantare le tue colture in base al periodo migliore 
                dell'anno.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">FAQ</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">
                    Perché l'esposizione cambia durante l'anno?
                  </h4>
                  <p className="text-sm text-gray-700">
                    Il sole cambia altezza nel cielo durante l'anno. In estate è più alto e le ombre sono più corte, 
                    in inverno è più basso e le ombre sono più lunghe. Questo significa che un ostacolo che blocca 
                    il sole in inverno potrebbe non bloccarlo in estate.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">
                    Come misurare altezza e distanza di un ostacolo?
                  </h4>
                  <p className="text-sm text-gray-700">
                    <strong>Altezza:</strong> Puoi stimare confrontando con oggetti di riferimento (es. un palazzo 
                    di 3 piani ≈ 9-10m). Oppure usa un'app di misurazione con il telefono.
                  </p>
                  <p className="text-sm text-gray-700 mt-1">
                    <strong>Distanza:</strong> Misura la distanza orizzontale dal punto centrale del tuo orto 
                    all'ostacolo. Puoi usare Google Maps per misurare distanze approssimative.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">
                    Gli alberi caducifoglie cambiano l'esposizione?
                  </h4>
                  <p className="text-sm text-gray-700">
                    Sì! Gli alberi che perdono le foglie in inverno cambiano drasticamente l'esposizione. 
                    In estate bloccano più sole, in inverno meno. Considera di aggiungere due set di ostacoli 
                    diversi per estate e inverno, oppure usa una media.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Link a sezioni correlate */}
        <section className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Sezioni Correlate</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link
              href="/app"
              className="flex items-center gap-3 p-3 bg-white rounded-lg hover:shadow-md transition-shadow"
            >
              <BarChart3 className="text-green-600" size={20} />
              <span className="text-gray-700">Dashboard</span>
            </Link>
            <Link
              href="/app/planner"
              className="flex items-center gap-3 p-3 bg-white rounded-lg hover:shadow-md transition-shadow"
            >
              <Calendar className="text-blue-600" size={20} />
              <span className="text-gray-700">Planner</span>
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
