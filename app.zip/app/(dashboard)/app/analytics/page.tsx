'use client'

import React, { useState, useEffect } from 'react'
import { useStorage } from '@/packages/core/hooks/useStorage'
import { useTier } from '@/packages/core/hooks/useTier'
import { ProFeatureGate } from '@/components/shared/ProFeatureGate'
import { ProfessionalDashboard } from '@/components/professional/Dashboard'
import HarvestAnalytics from '@/components/HarvestAnalytics'
import { HarvestLogData } from '@/types'

export default function AnalyticsPage() {
  const { storageProvider } = useStorage()
  const { tier, can } = useTier()
  const [harvests, setHarvests] = useState<HarvestLogData[]>([])
  const [garden, setGarden] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const gardens = await storageProvider.getGardens()
        if (gardens.length > 0) {
          setGarden(gardens[0])
          const harvestLogs = await storageProvider.getHarvestLogs(gardens[0].id)
          setHarvests(harvestLogs || [])
        }
      } catch (error) {
        console.error('Error loading analytics data:', error)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [storageProvider])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Caricamento...</p>
      </div>
    )
  }

  // PRO Professional: mostra dashboard aziendale completa
  if (tier === 'PRO_PROFESSIONAL') {
    return (
      <div className="min-h-screen">
        <ProfessionalDashboard />
      </div>
    )
  }

  // PRO Consumer: mostra analytics raccolti
  if (can('harvestAnalytics')) {
    return (
      <div className="min-h-screen p-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Analytics Raccolti</h1>
          {garden && (
            <HarvestAnalytics 
              harvests={harvests} 
              gardenId={garden.id}
            />
          )}
        </div>
      </div>
    )
  }

  // FREE: mostra feature gate
  return (
    <div className="min-h-screen">
      <ProFeatureGate
        feature="analytics"
        title="Analytics Avanzate"
        description="Visualizza analisi dettagliate dei tuoi raccolti, ROI e performance"
        requiredTier="PRO_CONSUMER"
        showPreview={true}
      >
        {garden && (
          <div className="p-6">
            <HarvestAnalytics 
              harvests={harvests} 
              gardenId={garden.id}
            />
          </div>
        )}
      </ProFeatureGate>
    </div>
  )
}




